function [X, BuildRepos,Adj] = DistCoreArranjo (k, n,p, s, l, L, Dist, BuildRepos,Adj)
Dist;
  % k = posição nas entradas ; n=n0 de distancias; p numero de pontos
  %; s= combinações ; l = resposta;
  
  if (k>s)
    X=l';
    
    Dist1 = [];
    Distu = [];
% define distancias usadas
    for i=1:3
    Dist1 = [Dist1, Dist(X(i,1))];
    end
% monta o primeiro core  
    Dist1;
    [Core,flag] = BuildCore(Dist1, 3);
    Core;
    Adj = ones(3) - eye(3);
    p=p-3;
    if (flag == 1) 
  % disp("Distancias incompativeis \n ---------------------");
    return
    end

%Nova Distancia // Novo atomo
      Dist2=Dist ;
      B = sort(X);
      for i=1:3
      Dist2(: , B(4-i,1))=[];
      end 
    [A, BuildRepos] = DistCombNewAtom(1, 3 ,p, 3, [1,2,3],[], Dist2, Core, BuildRepos, 0);
    

   return
      
  end
  if k==1
      m=1;
    else
      m=l(k-1) +1;
    end
  for (i=m:n-(s-k))    
    l(k)=i;
    [L,BuildRepos] = DistCoreArranjo(k+1,n,p,s,l, L, Dist, BuildRepos,Adj);
  end
  X=L;
 
end
