% Copyright (C) 2019 Gustavo
% 
% This program is free software: you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see
% <https://www.gnu.org/licenses/>.

% -*- texinfo -*- 
% @deftypefn {} {@var{retval} =} TRIBOND (@var{input1}, @var{input2})
%
% @seealso{}
% @end deftypefn

% Author: Gustavo <guscafe@NoteGus>
% Created: 2019-03-25



% ALGORITMO TRIBOND

%Experimentando para Npontos=6 e Dist=[1,1,1,2,2,2], dimensao dim=3

function retval = TRIBOND (Dist, Npontos)
dim=3;
%construindo primeiro core

%seleção das distancias
[m,n]=size(Dist);
  %disp(n);
   sorteio1 = [];
  for(k=1:3)
    c=round(rand(1)*n);
    if c==0
      c=c+1;
    end
    
  %loop para evitar repetições
   [ms,ns] = size(sorteio1);
    for (j=1:ns) 
      if ns>0   
        while c==sorteio1(:,j);
          c=round(rand(1)*n);
        end
      end
    end
    
  sorteio1 = [sorteio1,c];
    
  end
  %sorteio1
  Dist1 = [Dist(sorteio1(:,1)), Dist(sorteio1(:,2)), Dist(sorteio1(:,3))];
  Dist;
  Dist1
  X=zeros(dim);
  %Primeiro triangulo
  x1=[0,0]
  x2=[0,Dist1(1,1)]
  x3=[0,0];
  X(1,2)=norm(x1-x2)^2;
  X(1,3)=Dist1(1,2)^2;
  X(2,3)=(Dist1(1,3)^2); %<<<<<<<<<<<<<<<<<<<<!!!!
  for (i=1:3)
    for(j=1:3)
     X(j,i)=X(i,j);
    end
  end
  %Resolver sistema linear |xi-xj|^2=X(i,j) para achar x3
  %temos: <x1,x1>=0, <x1-x2,x1-x2>=<x2,x2>=X(1,2), 
  %similarmente, <x3,x3>=X(1,3). entao só precisamos resolver
  %<x2-x3,x2-x3> = X(2,3). que nos dá:
  %x2'*x3=(1/2)*(X(2,3) - X(1,3) - X(1,2))
  %---> x3(1,2) = -(1/2)*(X(2,3) - X(1,3) - X(1,2))
  
  X
  x3(1,2) = -(1/2)*(X(2,3) - X(1,3) - X(1,2));
  x3(1,1) = sqrt(abs(X(1,3)-x3(1,2)^2));
  x3
  normas=[norm(x1),norm(x2),norm(x3)]
 
 
 %PARA A PROXIMA REUNIÃO:
  %Vamos pensar em resolver em combinações _ _ _ para fazer o core.
  %pensar em ter um vetor de 0 e 1's para verificar se uma distância já foi usada
  %funções auxiliares para pedaços que se repetem muito
  %escrever primeiro o algoritmo à mão
  
  
endfunction
